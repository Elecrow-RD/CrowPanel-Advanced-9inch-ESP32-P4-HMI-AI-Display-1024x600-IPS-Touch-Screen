"""Pin ESP-Hosted host library to the version installed on the ESP32-C6."""

from esphome.components import esp32
import esphome.config_validation as cv

DEPENDENCIES = ["esp32_hosted"]
CONFIG_SCHEMA = cv.Schema({})


async def to_code(config):
    # Keep the P4 host library aligned with the C6 image currently installed
    # on the board (2.12.3 legacy).
    esp32.add_idf_component(name="espressif/esp_hosted", ref="2.12.3")
