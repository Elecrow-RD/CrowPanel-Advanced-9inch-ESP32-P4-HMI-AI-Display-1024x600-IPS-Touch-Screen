param(
  [string]$Port = "",
  [int]$Baud = 460800
)

$idf = "D:\esp-idf\5.5.1\extracted\esp-idf-v5.5.1"
$tool = "D:\esp-idf\5.4.2tool"
$python = "$tool\python_env\idf5.5_py3.11_env\Scripts\python.exe"
$esptool = "$idf\components\esptool_py\esptool\esptool.py"
$dir = Split-Path -Parent $MyInvocation.MyCommand.Path

if (-not (Test-Path $python)) { throw "ESP-IDF Python 环境不存在：$python" }
if (-not (Test-Path $esptool)) { throw "esptool.py 不存在：$esptool" }

$env:PATH = "$tool\tools\cmake\3.30.2\bin;$tool\tools\ninja\1.12.1;$tool\python_env\idf5.5_py3.11_env\Scripts;$idf\tools;" + $env:PATH

if ([string]::IsNullOrWhiteSpace($Port)) {
  $ports = [System.IO.Ports.SerialPort]::GetPortNames() | Where-Object { $_ -notin @("COM1", "COM3") }
  if ($ports.Count -eq 1) { $Port = $ports[0] }
  else { throw "未能唯一确定 C6 串口。请用 -Port COMxx 指定；当前检测到：$($ports -join ', ')" }
}

Write-Host "将擦除并烧录 ESP32-C6：$Port" -ForegroundColor Cyan
& $python $esptool --chip esp32c6 -p $Port -b $Baud --before default_reset --after hard_reset erase_flash
if ($LASTEXITCODE -ne 0) { throw "erase_flash 失败，退出码 $LASTEXITCODE" }

& $python $esptool --chip esp32c6 -p $Port -b $Baud --before default_reset --after hard_reset write_flash --flash_mode dio --flash_size 4MB --flash_freq 80m `
  0x0 "$dir\bootloader.bin" `
  0x8000 "$dir\partition-table.bin" `
  0xD000 "$dir\ota_data_initial.bin" `
  0x10000 "$dir\network_adapter.bin"
if ($LASTEXITCODE -ne 0) { throw "write_flash 失败，退出码 $LASTEXITCODE" }

Write-Host "C6 烧录完成。请拔掉 C6 外接 USB 串口，重新给 P4 上电，然后查看 P4 COM3 日志。" -ForegroundColor Green
