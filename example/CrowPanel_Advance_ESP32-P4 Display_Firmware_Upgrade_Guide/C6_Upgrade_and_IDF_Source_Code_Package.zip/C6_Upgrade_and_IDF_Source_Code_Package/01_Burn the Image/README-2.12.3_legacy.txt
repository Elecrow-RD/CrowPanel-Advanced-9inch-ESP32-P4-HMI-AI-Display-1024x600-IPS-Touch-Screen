

ESP32-C6 compatible firmware: official network_adapter 2.12.3

The c6_full_2.12.3_legacy_4MB.bin in this directory is a complete merged image containing:
bootloader, partition table, OTA data, and the official network_adapter 2.12.3.

Flashing parameters:
Chip: ESP32-C6
Address: 0x0
Flash: 4MB
Mode: DIO
Frequency: 80MHz

Before flashing, connect C6 BOOT to low level; the P4 needs its code erased or the reset button held down.

Command-line example (change the port as appropriate):
python -m esptool --chip esp32c6 -p COM11 -b 460800 erase_flash
python -m esptool --chip esp32c6 -p COM11 -b 460800 write_flash --flash_mode dio --flash_size 4MB --flash_freq 80m 0x0 c6_full_2.12.3_legacy_4MB.bin

Use this compatible image only if the 2.12.12 image still cannot establish an SDIO handshake.