

ESP32-C6 complete firmware (ESP-Hosted 2.12.12)

Recommended method: Use ESP Flash Download Tool or a flashing tool to select the following single merged image:

File: c6_full_2.12.12_4MB.bin
Address: 0x0
Chip: ESP32-C6
Flash: 4 MB
Mode: DIO
Frequency: 80 MHz

Before flashing, put the C6 into download mode: connect C6 BOOT to low level; the P4 needs its code erased or the reset button held down.

If using esptool.py, assuming the port is COM11:

python -m esptool --chip esp32c6 -p COM11 -b 460800 --before default_reset --after hard_reset erase_flash
python -m esptool --chip esp32c6 -p COM11 -b 460800 --before default_reset --after hard_reset write_flash --flash_mode dio --flash_size 4MB --flash_freq 80m 0x0 c6_full_2.12.12_4MB.bin

The components subdirectory retains the original files required for separate flashing:
bootloader.bin       -> 0x0
partition-table.bin  -> 0x8000
ota_data_initial.bin -> 0xD000
network_adapter.bin  -> 0x10000

Note: Do not flash network_adapter.bin alone to 0x0.