#pragma once

// #include "smart_gadget/SmartGadget.hpp"
#include "music_player/MusicPlayer.hpp"
#include "setting/Setting.hpp"
#include "game_2048/Game_2048.hpp"
#include "calculator/Calculator.hpp"
#include "camera/Camera.hpp"
#include "video_player/VideoPlayer.hpp"